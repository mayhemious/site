import React from "react";

function App() {
  return (
    <div className="App">
      <h1>3 Boyutlu Hayaller</h1>
      <p>3D yazıcı ile ürettiğimiz ürünlerin katalog sitesi.</p>
      {/* Ürün kartları buraya gelecek */}
    </div>
  );
}

export default App;
